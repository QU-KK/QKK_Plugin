import bpy
import json
import os
os.system('cls')

global Repeat_Mat_List
global Merge_Json

Mat_Name = 'None'  # 材质名称初始化
Shader_Name = 'None'  # Shader名称初始化
Value_list = []  # 参数列表初始化
Image_list = []  # 图像列表初始化

Repeat_Mat_List = []  # 重复材质列表初始化
Merge_Json = []  # 合并的JSON数据初始化

# 获取选中的物体
def get_obj():
    selected_objects = bpy.context.selected_objects  # 获取当前选中的物体
    if len(selected_objects) > 0:  # 选中物体>0
        for obj in selected_objects:  # 遍历物体
            if obj.id_data.type == 'MESH':  # Mesh类型
                get_mat(obj)  # 执行函数,获取材质

# 获取物体的材质
def get_mat(obj):
    global Mat_Name
    global Shader_Name
    global Value_list
    global Image_list
    global Repeat_Mat_List

    if len(obj.material_slots) > 0:  # 材质槽>0
        for slot in obj.material_slots:  # 遍历材质槽
            if slot.material != None:  # 判断材质槽有材质
                mat = slot.material  # 获取材质
                if mat.name not in Repeat_Mat_List:  # 材质名称不在重复材质列表中执行
                    Mat_Name = 'None'  # 初始化材质名称
                    Shader_Name = 'None'  # 初始化Shader名称
                    Value_list = []  # 初始化参数列表
                    Image_list = []  # 初始化图像列表
                    Repeat_Mat_List.append(mat.name)  # 将材质名称添加到重复材质列表
                    Mat_Name = mat.name  # 设置材质名称
                    get_shader(mat)  # 执行函数,获取Shader

# 获取Shader
def get_shader(mat):
    global Shader_Name
    node = mat.node_tree.nodes.get('Shader')  # 获取名为'Shader'的节点
    if node != None:  # 如果节点存在
        Shader_Name = node.node_tree.name  # 设置Shader名称
        get_parameter(mat)  # 执行函数,获取材质参数
        get_image(mat)  # 执行函数，获取材质图像
        merge_json()  # 执行函数,合并成JSON数据
    else:
        merge_json()  # 执行函数,如果没有名称为'Shader'节点，直接合并JSON数据

# 获取材质参数
def get_parameter(mat):
    global Value_list
    for Par in mat.node_tree.nodes['Shader'].inputs:  # 遍历着色器节点的输入
        Par_type = Par.type  # 获取参数类型
                    
        if Par_type == 'VALUE':  # 如果参数类型是值
            Parameter = f'{Par.name}={Par.default_value:.3f}'  # 参数名称和值
            Value_list.append(Parameter)  # 添加到参数列表
            
        if Par_type == 'RGBA':  # 如果参数类型是颜色
            Parameter = f'{Par.name}={Par.default_value[0]:.3f}, {Par.default_value[1]:.3f}, {Par.default_value[2]:.3f}, {Par.default_value[3]:.3f}' # 参数名称和值
            Value_list.append(Parameter)  # 添加到参数列表
            
        if Par_type == 'VECTOR':  # 如果参数类型是向量
            Parameter = f'{Par.name}={Par.default_value[0]:.3f}, {Par.default_value[1]:.3f}, {Par.default_value[2]:.3f}'  # 参数名称和值
            Value_list.append(Parameter)  # 添加到参数列表

# 获取材质中的图像
def get_image(mat):
    global Image_list
    # 获取图像槽名称和文件路径
    for node in mat.node_tree.nodes:  # 遍历材质节点树中的所有节点
        if node.type == 'TEX_IMAGE' and node.image != None:
            if os.path.exists(bpy.path.abspath(node.image.filepath)):  # 如果节点是图像纹理且图像存在                
                img_path = bpy.path.abspath(node.image.filepath)  # 获取图像的绝对路径
                Image = (node.name + '=' + img_path)  # 创建图像名称和路径的字符串
                Image_list.append(Image)  # 添加到图像列表

# 合并JSON数据
def merge_json():
    global Merge_Json
    json_data = {  # 创建一个字典用于存储材质信息
        'Mat_Name': Mat_Name,  # 材质名称
        'Shader_Name': Shader_Name,  # Shader名称
        'Parameters': Value_list,  # 参数列表
        'Images': Image_list    # 图像列表
    }    
    Merge_Json.append(json_data)  # 将字典添加到合并的JSON列表中

# 创建并写入JSON数据结构
def write_json():
    global Merge_Json
    # 导出为json
    file_path = 'C:\\Blender_UE\\Blender-Ue\\Mat.json'  # JSON文件路径
    # 将数据写入 JSON 文件
    with open(file_path, 'w', encoding='utf-8') as json_file:  # 打开文件进行写入
        json.dump(Merge_Json, json_file, indent=4, ensure_ascii=False)  # 将合并的JSON数据写入文件
    print(f'JSON 模板保存到: {file_path}')  # 打印保存路径

get_obj()  # 执行函数,获取选中的物体
write_json()  # 执行函数,写入JSON文件

# 
def export_fbx():
    
    #for mat in bpy.data.materials:
        #mat.use_nodes = False
    
    bpy.ops.export_scene.fbx(
    #输出路径
    filepath='C:\Blender_UE\Blender-Ue\SM.fbx',

    #包括
    use_selection=True,#选定物体
    use_visible=False,#可见物体
    use_active_collection=False,#活动集合
    #collection='',#集合名称
    object_types={'MESH'},#导出类型
    use_custom_props=True,#自定义属性

    #变换
    global_scale=1.0,#缩放
    apply_scale_options='FBX_SCALE_NONE',#应用缩放
    axis_forward='Y',
    axis_up='Z',
    apply_unit_scale=True,#应用单位
    use_space_transform=True,#使用空间变换
    bake_space_transform=False,#应用变换 True   Ue可能出问题

    #几何数据
    mesh_smooth_type='EDGE',#平滑类型  OFF FACE EDGE SMOOTH_GROUP
    use_subsurf=False,#导出表面细分
    use_mesh_modifiers=False,#应用修改器
    use_mesh_modifiers_render=False,#应用修改器（渲染）
    use_mesh_edges=False,#松散边
    use_triangles=False,#三角化
    use_tspace=False,#切向空间
    colors_type='SRGB',#顶点色类型
    prioritize_active_color=False,#活动颜色优先

    #骨架
    primary_bone_axis='Y',#主骨骼轴向
    secondary_bone_axis='X',#次骨骼轴向
    armature_nodetype='NULL',#骨架FBXNode类型
    add_leaf_bones=False,#仅形变骨骼
    use_armature_deform_only=False,#添加叶骨

    #动画
    bake_anim=False,
    bake_anim_use_all_bones=False,
    bake_anim_use_nla_strips=False,
    bake_anim_use_all_actions=False,
    bake_anim_force_startend_keying=False,
    bake_anim_step=1.0,
    bake_anim_simplify_factor=1.0,

    #其他
    check_existing=False,#检查是否存在
    filter_glob='',#过滤
    path_mode='AUTO',#路径模式
    embed_textures=False,#内嵌纹理
    batch_mode='OFF',#批量模式
    use_batch_own_dir=False,#批处理路径
    use_metadata=False,#使用元数据
    )
    
    #for mat in bpy.data.materials:
        #mat.use_nodes = True

export_fbx()