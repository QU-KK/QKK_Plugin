import bpy
import json
import os
os.system('cls')  # 清屏

# 获取Json数据
def Get_Json():
    # 设置要读取的 JSON 文件路径
    file_path = 'C:\\Blender_UE\\Blender-Ue\\Mat.json'  # 确保使用双反斜杠

    with open(file_path, 'r', encoding='utf-8') as json_file:
        # 解析 JSON 数据
        json_data = json.load(json_file)
        id=0
        for data in json_data:
            print()
            Mat_Name = data['Mat_Name']  # 材质名称
            Shader_Name = data['Shader_Name']  # 着色器名称
            Parameters = data['Parameters']  # 参数
            Images = data['Images']  # 图像
            
            # 检查材质是否存在
            if bpy.data.materials.get(Mat_Name) == None:
                id=id+1                
                print(id)
                print('新建材质:',Mat_Name)
                mat = bpy.data.materials.new(name=Mat_Name)  # 创建新材质
                mat_mod.material_slots[0].material = mat  # 将材质赋值给材质槽
                if Shader_Name != 'None':
                    print('Shader:',Shader_Name)
                    Set_Shader(mat, Shader_Name)  # 设置着色器
                    print('参数:',Parameters)
                    Set_Parameters(mat, Parameters)  # 设置参数
                    print('图像:',Images)
                    Set_Images(mat, Images)  # 设置图像
                else:
                    print('无Shader')
            else:
                print('材质已存在:',Mat_Name)

# 设置Shader
def Set_Shader(mat, Shader_Name):
    shader_path = "C:\\Blender_Shader\\" + Shader_Name + ".blend"  # 着色器文件路径
    # 文件名称
    base_name = os.path.basename(shader_path)
    # 替换字符
    group_name = base_name.replace('.blend', '_GROUP')  # 获取节点组名称
    
    shader_node = bpy.data.node_groups.get(group_name)  # 获取节点组
    # 判断节点组是否存在
    if shader_node != None:
        pass  # 如果存在，什么也不做
    else:
        # 关联节点
        bpy.ops.wm.append(directory=os.path.join(shader_path, 'NodeTree'), filename=group_name, link=True)
        
    # 锁定节点组
    bpy.data.node_groups[group_name].use_fake_user = True
    # 材质节点
    mat_nodes = mat.node_tree.nodes
    # 清空节点
    mat_nodes.clear()
    # 新建节点组
    node = mat_nodes.new(type='ShaderNodeGroup')
    # 设置节点树
    node.node_tree = bpy.data.node_groups[group_name]

    # 切换至材质视口
    bpy.context.area.ui_type = 'ShaderNodeTree'
    # 解散节点组
    bpy.ops.node.group_ungroup()
    # 切换回3D视口
    # bpy.context.area.ui_type = 'VIEW_3D'
    bpy.context.area.ui_type = 'TEXT_EDITOR'
    
# 设置参数
def Set_Parameters(mat, Parameters):
    node = mat.node_tree.nodes.get('Shader')  # 获取着色器节点
    for Param in Parameters:
        param_name = Param.split('=')[0]  # 获取参数名称
        param_value = Param.split('=')[1]  # 获取参数值
        
        # 根据参数值的格式设置值
        if len(param_value.split(',')) == 1:
            value = float(param_value)
            
        if len(param_value.split(',')) == 4:
            value = [float(v.strip()) for v in param_value.split(',')]
                                
        if len(param_value.split(',')) == 3:
            value = [float(v.strip()) for v in param_value.split(',')]
            
        node.inputs[param_name].default_value = value  # 设置节点输入的默认值

# 设置图像
def Set_Images(mat, Images):
    for image_node in Images:
        node_name = image_node.split('=')[0]  # 获取节点名称
        image_path = image_node.split('=')[1]  # 获取图像路径
        image_name = os.path.basename(image_path)  # 获取图像文件名
        get_image = bpy.data.images.get  # 获取图像的方法
        
        # 检查图像是否已存在且路径有效
        if get_image(image_name) == None and os.path.exists(image_path):
            bpy.data.images.load(image_path)  # 加载图像
        
        if get_image(image_name) != None:
            image = get_image(image_name)  # 获取图像
            mat.node_tree.nodes[node_name].image = image  # 将图像赋值给节点
            
            image.alpha_mode = 'CHANNEL_PACKED'  # 设置图像的 alpha 模式
            if '_m.' in image_name or '_n.' in image_name:
                image.colorspace_settings.name = 'Non-Color'  # 设置色彩空间

print('开始导入材质')
# 材质载体
bpy.ops.mesh.primitive_plane_add()  # 添加一个平面
bpy.ops.object.material_slot_add()  # 添加材质槽
mat_mod = bpy.context.active_object  # 获取当前活动对象
mat_mesh = mat_mod.data  # 获取对象的网格数据

# 执行函数
Get_Json()

# 删除材质载体
bpy.data.meshes.remove(mat_mesh)  # 移除创建的网格
print()
print('材质导入完毕')



def import_fbx():
        bpy.ops.wm.fbx_import(
        # 常规
        filepath='C:\Blender_UE\Blender-Ue\SM.fbx',#路径
        global_scale=1.0, #缩放
        use_custom_props=True, #自定义属性
        use_custom_props_enum_as_string=True, #导入枚举为字符串
        # 几何数据
        use_custom_normals=True, #自定义法向 True
        import_subdivision=False, #细分曲面
        import_colors='SRGB', #顶点色 SRGB NONE  LINEAR
        validate_meshes=True, #检查网格
        # 材质引用
        mtl_name_collision_mode='REFERENCE_EXISTING',#引用同名材质
        # 动画
        use_anim=False, #动画
        anim_offset=0.0, #动画偏移
        #骨骼
        ignore_leaf_bones=False, #忽略叶骨骼
        )
    
import_fbx()