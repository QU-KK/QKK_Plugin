bl_info = {
    "name": "SimpleBake",
    "author": "Lewis <www.toohey.co.uk/SimpleBake/support/>, iBlender@taobao.com",
    "version": (2, 8, 2),
    "blender": (4, 5, 2),
    "location": "Properties Panel -> Render Settings Tab",
    "description": "Simple baking of PBR and other textures",
    "warning": "",
    "doc_url": "https://blendermarket.com/products/simplebake---simple-pbr-and-other-baking-in-blender-2",
    "tracker_url": "https://item.taobao.com/item.htm?ft=t&id=750845614721",
    "category": "Object",
}

import bpy
from bpy.utils import register_class, unregister_class

from . import object_preperation
from . import image_management
from . import material_management
from . import external_save
from . import property_group
from . import uv_management
from . import copy_and_apply
from . import starting_checks
from . import utils
from . import background_and_progress
from . import channel_packing
from . import cleanup

from . import presets
from . import presets_local
from . import sketchfab_upload
from . import messages
from . import auto_cage
from . import aov
from . import preview_operators

from . import ui
from . import bake_operators







classes = ([
        ])

def register():
    global classes
    for cls in classes:
        register_class(cls)

    object_preperation.register()
    image_management.register()
    material_management.register()
    external_save.register()
    property_group.register()
    ui.register()
    uv_management.register()
    copy_and_apply.register()
    bake_operators.register()
    starting_checks.register()
    utils.register()
    background_and_progress.register()
    channel_packing.register()
    
    presets.register()
    presets_local.register()
    sketchfab_upload.register()
    messages.register()
    auto_cage.register()
    cleanup.register()
    aov.register()
    preview_operators.register()

    


def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
        
    object_preperation.unregister()
    image_management.unregister()
    material_management.unregister()
    external_save.unregister()
    property_group.unregister()
    ui.unregister()
    uv_management.unregister()
    copy_and_apply.unregister()
    bake_operators.unregister()
    starting_checks.unregister()
    utils.unregister()
    background_and_progress.unregister()
    channel_packing.unregister()
    
    presets.unregister()
    presets_local.unregister()
    sketchfab_upload.unregister()
    messages.unregister()
    auto_cage.unregister()
    cleanup.unregister()
    aov.unregister()
    preview_operators.unregister()
