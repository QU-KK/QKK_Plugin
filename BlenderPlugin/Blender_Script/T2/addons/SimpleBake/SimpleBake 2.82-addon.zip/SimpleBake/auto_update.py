import bpy
# from urllib.request import urlopen
# from bpy.utils import register_class, unregister_class
from bpy.types import Operator
# import base64
# from pathlib import Path
# import os
# import urllib.request
# import shutil

# from .utils import show_message_box
# from .messages import print_message

def ignore_delete_errors(func, path, exc_info):
    # This function is called when shutil.rmtree hits an error.
    # Just ignore the error and move on.
    print(f"Could not delete {path}. Ignoring. Reason: {exc_info[1]}")


class VersionControl:
    #Non-Blender class
    was_error = False
    at_current = True
    installed_version = False #Will be set by init - Tuple
    installed_version_str = ""
    current_version_str = ""
    just_updated = False
    
    @classmethod
    def check_at_current_version(cls, no_online_check):
        pass
    
class SimpleBake_OT_Auto_Update(Operator):
    """Download and install updated version of SimpleBake"""
    bl_idname = "simplebake.auto_update"
    bl_label = "Update"        
    
    def execute(self, context):
        return {'FINISHED'}
        

class SimpleBake_OT_Rollback_Update(Operator):
    """Download and install previous version of SimpleBake"""
    bl_idname = "simplebake.rollback_update"
    bl_label = "Rollback"

    def execute(self, context):
        return {'FINISHED'}
        


classes = ([
    SimpleBake_OT_Auto_Update,
    SimpleBake_OT_Rollback_Update
        ])

def register():
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
                
