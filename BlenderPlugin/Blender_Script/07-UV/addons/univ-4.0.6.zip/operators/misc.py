# SPDX-FileCopyrightText: 2026 Oxicid
# SPDX-License-Identifier: GPL-3.0-or-later


import bpy
import bmesh
import numpy as np

from bpy.types import Operator
from bpy.props import *
from collections import Counter

from bl_math import clamp
from .. import utils
from .. import utypes
from ..utypes import UMeshes, BBox
from .. import preferences
from ..preferences import prefs, univ_settings
from mathutils import Vector, Matrix


# noinspection PyTypeHints
class UNIV_OT_RandomColor(Operator):
    bl_idname = 'uv.univ_random_color'
    bl_label = 'Random Color'
    bl_options = {'REGISTER', 'UNDO'}

    island_type: EnumProperty(name='Island Type', default='UV', items=utils.ENUM(('UV', 'UV'), 'MESH'))
    channel: EnumProperty(name='Channel', items=utils.ENUM(('RGB', 'RGB'), 'R', 'G', 'B', 'A'))
    random_type: EnumProperty(name='Random Type', items=utils.ENUM('RANDOM', 'PROBABILITY'))

    probability: FloatProperty(name='Probability', min=0, max=1, default=0.5)
    probability_value: FloatProperty(name='Value', min=0, max=1, default=1.0)
    probability_color: FloatVectorProperty(name='Color', size=4, min=0, max=0, default=(0.5, 0.0, 0.0, 1.0), subtype='COLOR')

    rand_seed: IntProperty(name='Seed', default=0)

    def draw(self, context):
        layout = self.layout

        if self.random_type == 'PROBABILITY':
            layout.prop(self, 'probability', slider=True)
            if self.channel != 'RGB':
                layout.prop(self, 'probability_value', slider=True)
            else:
                layout.prop(self, 'probability_color', text='')
            layout.separator()

        layout.row(align=True).prop(self, 'channel', expand=True)
        layout.row(align=True).prop(self, 'random_type', expand=True)
        layout.row(align=True).prop(self, 'island_type', expand=True)

        layout.prop(self, 'rand_seed')


    def execute(self, context):
        if self.island_type == 'UV':
            umeshes = UMeshes(report=self.report)
            isl_type = utypes.Islands
        else:
            umeshes = UMeshes.calc_any_unique(report=self.report, verify_uv=False)
            isl_type = utypes.MeshIslands
        if not umeshes:
            return umeshes.update()

        if context.mode == 'EDIT_MESH':
            if self.island_type == 'MESH':
                umeshes.set_sync(True)
                for u in umeshes:
                    u.sync_valid = False

            selected, visible = umeshes.filtered_by_selected_and_visible_uv_faces()
            if selected:
                umeshes = selected
                calc_islands_type = isl_type.calc_selected
            else:
                umeshes = visible
                calc_islands_type = isl_type.calc_visible
        else:
            calc_islands_type = isl_type.calc_with_hidden


        seed = sum(id(umesh.obj) for umesh in umeshes) // len(umeshes) + self.rand_seed
        seed %= 2**28

        import random
        for umesh in umeshes:
            color_layer = self.create_and_get_color_attribute(umesh)

            for isl in calc_islands_type(umesh):
                seed += 3
                random.seed(seed)

                if self.random_type == 'PROBABILITY':
                    random.seed(seed)
                    if random.choices([True, False], weights=[self.probability, 1 - self.probability], k=1)[0]:
                        random.seed(seed)
                        if self.channel == 'RGB':
                            for crn in isl.corners_iter():
                                crn[color_layer] = self.probability_color
                        elif self.channel == 'R':
                            for crn in isl.corners_iter():
                                crn[color_layer][0] = self.probability_value
                        elif self.channel == 'G':
                            for crn in isl.corners_iter():
                                crn[color_layer][1] = self.probability_value
                        elif self.channel == 'B':
                            for crn in isl.corners_iter():
                                crn[color_layer][2] = self.probability_value
                        else:
                            for crn in isl.corners_iter():
                                crn[color_layer][3] = self.probability_value
                else:
                    if self.channel == 'RGB':
                        val = (random.random(), random.random(), random.random(), 1.0)
                        for crn in isl.corners_iter():
                            crn[color_layer] = val
                    elif self.channel == 'R':
                        val = random.random()
                        for crn in isl.corners_iter():
                            crn[color_layer][0] = val
                    elif self.channel == 'G':
                        val = random.random()
                        for crn in isl.corners_iter():
                            crn[color_layer][1] = val
                    elif self.channel == 'B':
                        val = random.random()
                        for crn in isl.corners_iter():
                            crn[color_layer][2] = val
                    else:
                        val = random.random()
                        for crn in isl.corners_iter():
                            crn[color_layer][3] = val

        umeshes.update()
        if not umeshes.is_edit_mode:
            umeshes.free()
            utils.update_area_by_type('VIEW_3D')

        return {'FINISHED'}

    @staticmethod
    def create_and_get_color_attribute(umesh):
        color_layer = umesh.bm.loops.layers.color.active
        if color_layer is None:
            color_layer = umesh.bm.loops.layers.float_color.active
        if color_layer is None:
            color_layer = umesh.bm.loops.layers.color.new('Color')

        # Set to active.
        attr = umesh.obj.data.attributes
        if not attr.active_color or attr.active_color.name != color_layer.name:
            if not umesh.is_edit_bm:
                umesh.bm.to_mesh(umesh.obj.data)
            attr.active_color = attr[color_layer.name]

        changed = False
        for area in utils.get_areas_by_type('VIEW_3D'):
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    if space.shading.type == 'SOLID':
                        if space.shading.color_type != 'VERTEX':
                            space.shading.color_type = 'VERTEX'
                            changed = True
                    elif space.shading.type == 'WIREFRAME':
                        space.shading.type = 'SOLID'
                        space.shading.color_type = 'VERTEX'
                        changed = True
        if changed:
            bpy.context.view_layer.update()

        return color_layer

# noinspection PyTypeHints
class UNIV_OT_LinearGradient(Operator):
    bl_idname = 'uv.univ_linear_gradient'
    bl_label = 'Linear Gradient'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Gradients from boundary box"

    use_union_bbox: BoolProperty(name='Use Union Boundary Box')
    min_value: FloatProperty(name='Min', soft_min=0, soft_max=1, default=0)
    max_value: FloatProperty(name='Max', soft_min=0, soft_max=1, default=1)
    scale: FloatProperty(name='Scale', soft_min=0, soft_max=2, default=1)
    invert: BoolProperty(name='Invert', default=False)
    axis: EnumProperty(name='Axis', default='VERTICAL', items=utils.ENUM('HORIZONTAL', 'VERTICAL'))
    channel: EnumProperty(name='Channel', items=utils.ENUM(('RGB', 'RGB'), 'R', 'G', 'B', 'A'))

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'use_union_bbox')
        layout.prop(self, 'min_value', slider=True)
        layout.prop(self, 'max_value', slider=True)
        layout.prop(self, 'scale', slider=True)
        layout.prop(self, 'invert')

        layout.row(align=True).prop(self, 'axis', expand=True)
        layout.row(align=True).prop(self, 'channel', expand=True)

    def execute(self, context):
        umeshes = UMeshes(report=self.report)

        if context.mode == 'EDIT_MESH':
            selected, visible = umeshes.filtered_by_selected_and_visible_uv_faces()
            if selected:
                umeshes = selected
                calc_islands_type = utypes.Islands.calc_selected
            else:
                umeshes = visible
                calc_islands_type = utypes.Islands.calc_visible
        else:
            calc_islands_type = utypes.Islands.calc_with_hidden


        bb = utypes.BBox()
        for umesh in umeshes:
            islands = calc_islands_type(umesh)
            umesh.sequence = islands
            bb.union(islands.calc_bbox())

        if self.channel == 'R':
            set_channel_idx = 0
        elif self.channel == 'G':
            set_channel_idx = 1
        elif self.channel == 'B':
            set_channel_idx = 2
        else:
            set_channel_idx = 3

        center = (self.min_value + self.max_value) / 2
        output_min = (self.min_value - center) * self.scale + center
        output_max = (self.max_value - center) * self.scale + center
        if self.invert:
            output_min, output_max = output_max, output_min

        x_or_y_component = 0
        is_vertical = (self.axis == 'VERTICAL')
        if is_vertical:
            x_or_y_component = 1

        for umesh in umeshes:
            uv = umesh.uv
            islands: utypes.Islands = umesh.sequence
            color_layer = UNIV_OT_RandomColor.create_and_get_color_attribute(umesh)

            for isl in islands:
                if not self.use_union_bbox:
                    bb = isl.bbox

                if is_vertical:
                    input_min = bb.ymin
                    input_max = bb.ymax

                else:
                    input_min = bb.xmin
                    input_max = bb.xmax

                if self.channel == 'RGB':
                    for crn in isl.corners_iter():
                        val = utils.remap(crn[uv].uv[x_or_y_component], input_min, input_max, output_min, output_max)
                        val = clamp(val)
                        crn[color_layer] = Vector((val, val, val, 1.0))
                else:
                    for crn in isl.corners_iter():
                        val = utils.remap(crn[uv].uv[x_or_y_component], input_min, input_max, output_min, output_max)
                        crn[color_layer][set_channel_idx] = clamp(val)
        umeshes.update()
        if not umeshes.is_edit_mode:
            umeshes.free()
            utils.update_area_by_type('VIEW_3D')

        return {'FINISHED'}



class UNIV_OT_TD_PresetsProcessing(Operator):
    bl_idname = "scene.univ_td_presets_processing"
    bl_label = "Presets Processing"
    # noinspection PyTypeHints
    operation_type: EnumProperty(default='ADD',
                                 options={'SKIP_SAVE'},
                                 items=(('ADD', 'Add', ''),
                                        ('REMOVE', 'Remove', ''),
                                        ('REMOVE_ALL', 'Remove All', ''))
                                 )

    def execute(self, _context):
        match self.operation_type:
            case 'ADD':
                self.add()
            case 'REMOVE':
                self.remove()
            case 'REMOVE_ALL':
                univ_settings().texels_presets.clear()
                univ_settings().active_td_index = -1
        for a in utils.get_areas_by_type('VIEW_3D'):
            a.tag_redraw()
        for a in utils.get_areas_by_type('IMAGE_EDITOR'):
            a.tag_redraw()

        return {'FINISHED'}

    def add(self):
        td_presets = univ_settings().texels_presets
        if len(td_presets) >= 8:
            self.report({'WARNING'}, 'The preset limit of 8 units has been reached')
            return

        active_td_index = self.sanitize_index()

        my_user: preferences.UNIV_TexelPreset = univ_settings().texels_presets.add()
        my_user.name = str(round(univ_settings().texel))
        my_user.unit = univ_settings().texel_unit
        # NOTE: Add 'unit' before 'texel' for avoid 'set_transform'.
        my_user.texel = univ_settings().texel
        my_user.size_x = univ_settings().size_x
        my_user.size_y = univ_settings().size_y
        my_user.name += ' ' + utils.glob_resolutions_to_name()

        if len(td_presets) > 1:
            td_presets.move(len(td_presets), active_td_index + 1)
            univ_settings().active_td_index = active_td_index + 1
        else:
            univ_settings().active_td_index = len(td_presets) - 1

    def remove(self):
        td_presets = univ_settings().texels_presets
        if not len(td_presets):
            self.report({'WARNING'}, 'The preset is empty')
            return
        active_td_index = self.sanitize_index()
        if len(td_presets) == active_td_index - 1:
            univ_settings().active_td_index = -1
        td_presets.remove(active_td_index)
        self.sanitize_index()

    @staticmethod
    def sanitize_index():
        active_td_index = univ_settings().active_td_index
        td_presets = univ_settings().texels_presets

        if active_td_index < 0:
            active_td_index = len(td_presets) + active_td_index
        if active_td_index < 0 or active_td_index >= len(td_presets):
            active_td_index = len(td_presets) - 1
        univ_settings().active_td_index = active_td_index
        return active_td_index


class UNIV_OT_Join(Operator):
    bl_idname = "object.univ_join"
    bl_label = "Join"
    bl_description = "Join with preserve uv channels"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # TODO: Sanitize UV-names in materials (scip if not assign material)
        # TODO: Fix uv names in other obj by sanitized material
        return context.active_object  # TODO: Without selected

    def execute(self, context):
        active_obj_type = context.active_object.type
        if active_obj_type == 'EMPTY':
            self.report({'WARNING'}, f"Empty object cannot be joined")
            return {'CANCELLED'}
        counter_obj_for_join = 0
        for obj in context.selected_objects:
            if obj.type == active_obj_type:
                counter_obj_for_join += 1
                if counter_obj_for_join > 1:
                    break
        else:
            self.report({'WARNING'}, f"There must be more than one {active_obj_type.capitalize()} type object")
            return {'CANCELLED'}

        if active_obj_type == 'MESH':
            objects = utils.calc_any_unique_obj()
            removed_extra_channels_counter = sum(self.sanitize_uv(self.report, obj.data) for obj in objects)

            uv_names, conflicts_counter = self.sanitize_attr_names_and_get_names(objects)

            max_uv_size = max(len(obj.data.uv_layers) for obj in objects)
            added_uvs_counter = 0
            for obj in objects:
                added_uvs_counter += self.add_missed_uvs(obj, max_uv_size)
                self.rename_uvs(self.report, uv_names, obj.data)

            info = ''
            if conflicts_counter:
                info += f"Resolver {conflicts_counter} names conflicts. "
            if removed_extra_channels_counter:
                info += f"Removed {removed_extra_channels_counter} extra channels in total."
            if added_uvs_counter:
                info += f"Added {added_uvs_counter} channels in total."

            if info:
                self.report({'WARNING'}, info)

        return bpy.ops.object.join()

    @staticmethod
    def sanitize_attr_names_and_get_names(objects):
        conflict_attr_name = '_CONFLICT_WITH_UV'
        active_uv_layers = bpy.context.active_object.data.uv_layers
        uv_names_counter = [Counter() for _ in range(8)]
        for obj in objects:
            for idx, uv in enumerate(obj.data.uv_layers):
                uv_names_counter[idx][uv.name] += 1

        uv_names = [uv.name for uv in active_uv_layers]
        for idx, counter in enumerate(uv_names_counter[len(active_uv_layers):]):
            frequent_uv_name = max(counter, key=counter.get, default=None)
            if frequent_uv_name is None:
                break
            uv_names.append(frequent_uv_name)

        # Remove potential '_CONFLICT_WITH_UV' name in uv maps
        for idx, uv_name in enumerate(uv_names):
            if conflict_attr_name in uv_name:
                uv_names[idx] = uv_name.replace(conflict_attr_name, str(idx))

        # Remove names for count conflict names
        for idx, uv in enumerate(active_uv_layers):
            if uv.name in uv_names_counter[idx]:
                del uv_names_counter[idx][uv.name]
        conflicts_counter = sum(len(c) for c in uv_names_counter)

        # Rename attributes for resolve potential name conflict
        for obj in objects:
            for attr in obj.data.attributes:
                if any((uv.name == attr.name) for uv in obj.data.uv_layers):
                    continue

                if attr.name in uv_names:
                    conflicts_counter += 1
                    attr.name += conflict_attr_name
        return uv_names, conflicts_counter

    @staticmethod
    def add_missed_uvs(obj, target_size, active_index=8):
        assert target_size <= 8
        mesh = obj.data
        mesh_uv_size = len(mesh.uv_layers)
        if target_size == 0 or mesh_uv_size == target_size or mesh_uv_size >= 8:
            return 0

        if mesh.uv_layers:
            if active_index > len(mesh.uv_layers) - 1:
                uv = mesh.uv_layers[-1]
            else:
                uv = mesh.uv_layers[active_index]

            uv_coords = np.empty(len(mesh.loops) * 2, dtype='float32')
            uv.data.foreach_get("uv", uv_coords)
            while (len(mesh.uv_layers)) < target_size:
                uv = mesh.uv_layers.new(do_init=False)
                uv.data.foreach_set("uv", uv_coords)  # noqa
        else:
            while (len(mesh.uv_layers)) < target_size:
                mesh.uv_layers.new(do_init=True)
        return target_size - mesh_uv_size

    @staticmethod
    def rename_uvs(report, names, mesh):
        assert len(mesh.uv_layers) == len(names)
        changed = False
        for _ in range(10):
            renamed = True
            for uv, new_name in zip(mesh.uv_layers, names):
                if uv.name != new_name:
                    uv.name = new_name
                    renamed = False
                    changed = True
            if renamed:
                return changed
        if preferences.debug():
            report({'WARNING'}, f'Mesh {mesh.name} do not rename uv layers')
        return changed

    @staticmethod
    def sanitize_uv(report, mesh):
        counter = 0
        if len(mesh.uv_layers) > 8:
            for uv in reversed(mesh.uv_layers[8:]):
                mesh.uv_layers.remove(uv)
                counter += 1
            report({'WARNING'}, f'Mesh {mesh.name} delete {counter} extra channels')
        return counter


class UNIV_OT_Hide(Operator):
    bl_idname = "uv.univ_hide"
    bl_label = 'Hide'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = f"Hide selected or unselected UV"
    # noinspection PyTypeHints
    unselected: BoolProperty(name='Unselected', default=False)

    def invoke(self, context, event):
        if not (context.area.type == 'IMAGE_EDITOR' and context.area.ui_type == 'UV'):
            self.report({'WARNING'}, 'Active area must be UV type')
            return {'CANCELLED'}

        if event.value == 'PRESS':
            self.max_distance = utils.get_max_distance_from_px(prefs().max_pick_distance, context.region.view2d)
            self.mouse_pos = Vector(context.region.view2d.region_to_view(event.mouse_region_x, event.mouse_region_y))
            return self.execute(context)
        return self.execute(context)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.umeshes: UMeshes | None = None
        self.max_distance: float = 0.0
        self.mouse_pos: Vector | None = None

    def execute(self, context):
        if bpy.context.mode != 'EDIT_MESH':
            self.report({'WARNING'}, 'Expect Edit Mode.')
            return {'CANCELLED'}

        self.umeshes = UMeshes(report=self.report)
        self.umeshes.fix_context()

        # NOTE: Filter before changing mode.
        selected_umeshes, visible_umeshes = self.umeshes.filtered_by_selected_and_visible_uv_by_context()

        if not self.umeshes.sync:
            # Fix incorrect for hide in non-sync mode
            if utils.get_select_mode_mesh() != 'FACE':
                self.umeshes.sync = True
                self.umeshes._elem_mode = ''  # noqa
                self.umeshes.elem_mode = 'FACE'
                utils.update_area_by_type('VIEW_3D')
            self.umeshes.sync = False

        self.umeshes = selected_umeshes if selected_umeshes else visible_umeshes

        if not self.umeshes:
            return self.umeshes.update()
        if not selected_umeshes and self.mouse_pos:
            return self.pick_hide()

        if utils.USE_GENERIC_UV_SYNC:
            return bpy.ops.uv.hide(unselected=self.unselected)


        # ================================================================================
        # Legacy
        # ================================================================================

        # Unselected
        if self.unselected:
            self.umeshes.umeshes.extend(visible_umeshes.umeshes.copy())
            for umesh in self.umeshes:
                unselected_faces = utils.calc_unselected_uv_faces(umesh)
                if umesh.sync:
                    utils.linked_hide_faces_for_3d(unselected_faces)
                else:
                    for f in unselected_faces:
                        f.select = False

                umesh.update_tag = bool(unselected_faces)
                if unselected_faces:
                    umesh.bm.select_flush(True)
            self.umeshes.update(info='Not found unselected faces')
            return {'FINISHED'}
        # Selected
        if self.umeshes.sync:
            if self.umeshes.elem_mode == 'FACE':
                return bpy.ops.uv.hide(unselected=False)

            self.umeshes.filter_by_selected_mesh_faces()
            if not self.umeshes:
                # TODO: Implement hide by view box
                return bpy.ops.uv.hide(unselected=False)

            if self.umeshes.elem_mode == 'VERT':
                self.vert_hide_sync_preprocessing()
            elif self.umeshes.elem_mode == 'EDGE':
                self.edge_hide_sync_preprocessing()

            res = bpy.ops.uv.hide(unselected=False)
            for umesh in self.umeshes:
                if umesh.sequence:
                    for f in umesh.sequence:
                        f.hide_set(False)
                    umesh.update()
                if preferences.debug():
                    if umesh.total_face_sel or umesh.total_edge_sel or umesh.total_vert_sel:
                        self.report({'WARNING'},
                                    'Undefined Behavior: Has selected elements even after applying Hide operation')
            return res
        else:
            # bpy.ops.uv.hide sometimes works incorrectly in 'FACE' mode too,
            # maybe it's something to do with not updating bm.select_mode
            for umesh in self.umeshes:
                uv = umesh.uv
                update_tag = False
                for f in utils.calc_visible_uv_faces(umesh):
                    if any(crn[uv].select for crn in f.loops):
                        f.select = False
                        update_tag = True
                umesh.update_tag = update_tag
            return self.umeshes.update()

    def pick_hide(self):
        hit = utypes.IslandHit(self.mouse_pos, self.max_distance)
        all_islands = []
        for umesh in self.umeshes:
            for isl in utypes.Islands.calc_visible(umesh):
                if self.unselected:
                    all_islands.append(isl)
                hit.find_nearest_island_by_crn(isl)

        if not hit:
            self.report({'INFO'}, 'Island not found within a given radius')
            return {'CANCELLED'}

        if self.unselected:
            if len(all_islands) == 1:
                self.report({'INFO'}, 'No found unpicked islands for hiding')
                return {'FINISHED'}

            hit.island.tag = False
            hit.island.umesh.update_tag = False
            for isl in all_islands:
                if isl.tag:
                    isl.hide_first()
                    isl.umesh.update_tag = True
            return self.umeshes.update()
        else:
            hit.island.hide_first()
            hit.island.umesh.update()
        return {'FINISHED'}

    def vert_hide_sync_preprocessing(self):
        def is_hide_face():
            for crn in f.loops:
                crn_vert = crn.vert
                if crn_vert.select:
                    if all(not f__.select for f__ in crn_vert.link_faces):
                        return True
                    for crn__ in utils.linked_crn_to_vert_pair_iter(crn, uv, True):
                        if crn__.face.select:
                            return True
            return False

        for umesh in self.umeshes:
            uv = umesh.uv
            visible_faces = utils.calc_visible_uv_faces(umesh)
            for f in visible_faces:
                # Skip selected and unselected face
                if f.select or not any(crn_.vert.select for crn_ in f.loops):
                    continue
                if not is_hide_face():
                    umesh.sequence.append(f)

    def edge_hide_sync_preprocessing(self):
        def is_hide_face():
            for crn in f.loops:
                if crn.edge.select:
                    pair = crn.link_loop_radial_prev
                    pair_face = pair.face
                    if pair_face.hide:
                        return True

                    if utils.is_pair(crn, crn.link_loop_radial_prev, uv):
                        return True
                    else:
                        if pair_face.select:
                            continue
                        else:
                            return True
            return False

        for umesh in self.umeshes:
            uv = umesh.uv
            visible_faces = utils.calc_visible_uv_faces(umesh)
            for f in visible_faces:
                # Skip selected and unselected face
                if f.select or not any(crn_.edge.select for crn_ in f.loops):
                    continue

                if not is_hide_face():
                    umesh.sequence.append(f)


LAST_MOUSE_POS = -100_000, -100_000
REPEAT_MOUSE_POS_COUNT = 0


class UNIV_OT_SetCursor2D(Operator):
    bl_idname = "uv.univ_set_cursor_2d"
    bl_label = 'Set Cursor 2D'

    # TODO: Implement 3D Ctrl + Shift + Right Mouse Button for consistent with 2D

    def invoke(self, context, event):
        if not (context.area.type == 'IMAGE_EDITOR' and context.area.ui_type == 'UV'):
            self.report({'WARNING'}, 'Active area must be UV type')
            return {'CANCELLED'}

        global LAST_MOUSE_POS
        global REPEAT_MOUSE_POS_COUNT
        int_mouse_pos = (event.mouse_region_x, event.mouse_region_y)
        if LAST_MOUSE_POS == int_mouse_pos:
            REPEAT_MOUSE_POS_COUNT += 1
        else:
            REPEAT_MOUSE_POS_COUNT = 0
            LAST_MOUSE_POS = int_mouse_pos

        if REPEAT_MOUSE_POS_COUNT >= 3:
            REPEAT_MOUSE_POS_COUNT = 0

        max_distance = utils.get_max_distance_from_px(prefs().max_pick_distance, context.region.view2d)
        mouse_pos = Vector(context.region.view2d.region_to_view(*int_mouse_pos))

        # Set active trim
        self.set_active_trim(mouse_pos)

        pt = None
        min_dist = max_distance
        mouse_pos = mouse_pos

        if REPEAT_MOUSE_POS_COUNT != 1:
            if context.mode == 'EDIT_MESH' and REPEAT_MOUSE_POS_COUNT == 0:
                grid_pt = Vector(utils.round_threshold(v, 1/2) for v in mouse_pos)
                grid_dist = (grid_pt - mouse_pos).length * 2.0
                if grid_dist < min_dist:
                    pt = grid_pt
                    min_dist = grid_dist
            else:
                zoom = utypes.View2D.get_zoom(context.region.view2d)
                divider = 1 / 8 if zoom <= 1600 else 1 / 64
                divider = divider if zoom <= 12800 else 1 / 64 / 8

                grid_pt = Vector(utils.round_threshold(v, divider) for v in mouse_pos)
                grid_dist = (grid_pt - mouse_pos).length
                if grid_dist < min_dist:
                    pt = grid_pt
                    min_dist = grid_dist

        # TODO: Implement Object Mode
        if context.mode == 'EDIT_MESH' and REPEAT_MOUSE_POS_COUNT == 0:
            umeshes = UMeshes()
            pt, min_dist = self.snap_to_trim(pt, mouse_pos, min_dist)

            zero_pt = Vector((0.0, 0.0))
            for umesh in umeshes:
                uv = umesh.uv
                if prefs().snap_points_default == 'ALL':
                    for f in utils.calc_visible_uv_faces_iter(umesh):
                        face_center_sum = zero_pt.copy()
                        corners = f.loops
                        prev_co = corners[-1][uv].uv
                        for crn in corners:
                            cur_co = crn[uv].uv
                            dist = (cur_co - mouse_pos).length
                            if dist < min_dist:
                                pt = cur_co
                                min_dist = dist
                            edge_center = (prev_co + cur_co) * 0.5
                            dist = (edge_center - mouse_pos).length
                            if dist < min_dist:
                                pt = edge_center
                                min_dist = dist

                            prev_co = cur_co
                            face_center_sum += cur_co
                        face_center = face_center_sum / len(corners)
                        dist = (face_center - mouse_pos).length
                        if dist < min_dist:
                            pt = face_center
                            min_dist = dist

                elif umeshes.elem_mode == 'VERT':
                    for f in utils.calc_visible_uv_faces_iter(umesh):
                        for crn in f.loops:
                            uv_co = crn[uv].uv
                            length = (mouse_pos - uv_co).length
                            if length < min_dist:
                                pt = uv_co
                                min_dist = length
                elif umeshes.elem_mode == 'EDGE':
                    for f in utils.calc_visible_uv_faces_iter(umesh):
                        corners = f.loops
                        prev_co = corners[-1][uv].uv
                        for crn in corners:
                            cur_co = crn[uv].uv
                            dist = (cur_co - mouse_pos).length
                            if dist < min_dist:
                                pt = cur_co
                                min_dist = dist
                            edge_center = (prev_co + cur_co) * 0.5
                            dist = (edge_center - mouse_pos).length
                            if dist < min_dist:
                                pt = edge_center
                                min_dist = dist
                            prev_co = cur_co
                else:
                    for f in utils.calc_visible_uv_faces_iter(umesh):
                        face_center_sum = zero_pt.copy()
                        corners = f.loops
                        for crn in corners:
                            cur_co = crn[uv].uv
                            dist = (cur_co - mouse_pos).length
                            if dist < min_dist:
                                pt = cur_co
                                min_dist = dist
                            face_center_sum += cur_co
                        face_center = face_center_sum / len(corners)
                        dist = (face_center - mouse_pos).length
                        if dist < min_dist:
                            pt = face_center
                            min_dist = dist

        if not pt:
            if REPEAT_MOUSE_POS_COUNT == 1:
                self.report({'INFO'}, 'Force Set Cursor 2D to Mouse position')
            pt = mouse_pos
        elif REPEAT_MOUSE_POS_COUNT == 2:
            self.report({'INFO'}, 'Force Set Cursor 2D to Grid')

        context.space_data.cursor_location = pt
        if context.space_data.pivot_point != 'CURSOR':
            from . import toggle
            from .. import draw
            toggle.PREV_PIVOT = context.space_data.pivot_point
            context.space_data.pivot_point = 'CURSOR'

            draw.TextDraw.max_draw_time = 1.8
            draw.TextDraw.draw(f"Switch Pivot to 'Cursor'")
        return {'FINISHED'}

    @staticmethod
    def snap_to_trim(pt, mouse_pos, min_dist):
        if not prefs().use_trims:
            return pt, min_dist

        for trim in utils.get_trim_bboxes():
            center = trim.center
            new_dist = (center - mouse_pos).length
            if new_dist < min_dist:
                pt = center
                min_dist = new_dist

            for crn_pt in trim.draw_data_verts():
                new_dist = (crn_pt - mouse_pos).length
                if new_dist < min_dist:
                    pt = crn_pt
                    min_dist = new_dist

            for (line_a, line_b) in utils.reshape_to_pair(trim.draw_data_lines()):
                line_center = (line_a + line_b) * 0.5
                new_dist = (line_center - mouse_pos).length
                if new_dist < min_dist:
                    pt = line_center
                    min_dist = new_dist

        return pt, min_dist


    @staticmethod
    def set_active_trim(mouse_pos):
        idx = -1
        min_dist = float('inf')
        if prefs().use_trims and prefs().trims_presets_slots:
            slot = prefs().get_active_trim_slot()
            for i, trim in enumerate(slot.trims_preset):
                if not trim.visible:
                    continue
                bb = BBox(trim.x, trim.x + trim.width, trim.y, trim.y + trim.height)

                if mouse_pos in bb:
                    for (l_a, l_b) in utils.reshape_to_pair(bb.draw_data_lines()):
                        _, dist = utils.intersect_point_line_segment(mouse_pos, l_a, l_b)
                        if dist < min_dist:
                            min_dist = dist
                            idx = i

            if idx != -1:
                slot.active_trim_index = idx


class UNIV_OT_Focus(Operator):
    bl_idname = "uv.univ_focus"
    bl_label = 'Focus'

    def invoke(self, context, event):
        if not (context.area.type == 'IMAGE_EDITOR' and context.area.ui_type == 'UV'):
            self.report({'WARNING'}, 'Active area must be UV type')
            return {'CANCELLED'}
        assert context.mode == 'EDIT_MESH'

        bounds = BBox()
        umeshes = UMeshes()
        color = (1, 1, 0, 1)
        for umesh in umeshes:
            uv = umesh.uv
            if umesh.sync and umesh.elem_mode in ('FACE', 'ISLAND'):
                bounds.update(crn[uv].uv for f in utils.calc_selected_uv_faces_iter(umesh) for crn in f.loops)
            else:
                bounds.update(crn[uv].uv for crn in utils.calc_selected_uv_vert_iter(umesh))
        if bounds == BBox():
            color = (0, 1, 1, 1)
            for umesh in umeshes:
                uv = umesh.uv
                bounds.update(crn[uv].uv for crn in utils.calc_visible_uv_corners_iter(umesh))
        if bounds == BBox():
            color = (1, 0, 0, 1)
            bounds.xmin = 0.0
            bounds.ymin = 0.0
            bounds.xmax = 1.0
            bounds.ymax = 1.0

        lines = bounds.draw_data_lines()

        n_panel_width = next(r.width for r in context.area.regions if r.type == 'UI')
        tools_width = next(r.width for r in context.area.regions if r.type == 'TOOLS')
        bounds.scale(1.2)  # Add padding

        space_data = context.area.spaces.active
        sima = utypes.SpaceImage.get_fields(space_data)

        image_size = [256, 256]
        aspect = [1, 1]
        if space_data.image:
            image_width_, image_height_ = space_data.image.size
            if image_height_:
                aspect = list(space_data.image.display_aspect)
                image_size[:] = image_width_, image_height_
        image_size_without_aspect = image_size.copy()

        image_size[0] *= aspect[0]
        image_size[1] *= aspect[1]

        # adjust offset and zoom
        c_region = utypes.ARegion(context.region)

        zero_division_avoid = 0.00001
        size_y = c_region.winrct.height / ((bounds.height + zero_division_avoid) * image_size[1])
        size_x = (c_region.winrct.width - n_panel_width - tools_width) / ((bounds.width + zero_division_avoid) * image_size[0])

        zoom = max(min(size_x, size_y), 0.05)
        if zoom > 100.0:
            zoom = 100.0

        offset_x = (n_panel_width - tools_width) / zoom / 2
        sima.xof = round((bounds.center_x - 0.5) * image_size[0] + offset_x)
        sima.yof = round((bounds.center_y - 0.5) * image_size[1])

        # sima_zoom_set
        old_zoom = sima.zoom
        sima.zoom = zoom
        if zoom < 0.1 or zoom > 4.0:
            w, h = image_size_without_aspect
            w *= zoom
            h *= zoom
            if (w < 4) and (h < 4) and zoom < old_zoom:
                sima.zoom = old_zoom
            elif c_region.winrct.width <= zoom:
                sima.zoom = old_zoom
            elif c_region.winrct.height <= zoom:
                sima.zoom = old_zoom

        from .. import draw
        draw.LinesDrawSimple.draw_register(lines, color)

        context.region.tag_redraw()
        return {'FINISHED'}


class UNIV_OT_UV_Layers_Manager(Operator):
    bl_idname = 'uv.univ_layers_manager'
    bl_label = 'UV Maps'
    bl_options = {'REGISTER', 'UNDO'}
    # noinspection PyTypeHints
    action: EnumProperty(default='ADD',
                                 options={'HIDDEN'},
                                 items=(('ADD', 'Add', ''),
                                        ('REMOVE', 'Remove', ''),
                                        ('RESET_NAMES', 'Reset Names', ''),

                                        ('SORT', 'Sort', ''),
                                        ('SYNC_SEAMS', 'Sync Seams', ''),
                                        ('SET_ACTIVE_RENDER', 'Set Active Render', ''),
                                        )
                         )

    @classmethod
    def poll(cls, context):
        return context.active_object

    def invoke(self, context, event):
        if event.value == 'PRESS':
            return self.execute(context)

        return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    @staticmethod
    def update_uv_layers_props():
        preferences.UV_LAYERS_ENABLE = False
        try:
            UNIV_OT_UV_Layers_Manager.update_uv_layers_props_ex()
        except:  # noqa
            if preferences.debug():
                import traceback
                traceback.print_exc()
        finally:
            preferences.UV_LAYERS_ENABLE = True

    @staticmethod
    def update_uv_layers_props_ex():
        settings = univ_settings()
        context = bpy.context
        active_obj = context.active_object

        if context.mode == 'EDIT_MESH':
            if not active_obj or active_obj.type != 'MESH':
                if settings.uv_layers_size:
                    settings.uv_layers_size = 0
                    utils.update_univ_panels()
                return
            selected_objects = context.objects_in_mode_unique_data
        else:

            if not active_obj or active_obj.type != 'MESH':
                if settings.uv_layers_size:
                    settings.uv_layers_size = 0
                    utils.update_univ_panels()
                return
            selected_objects = (obj_ for obj_ in context.selected_objects if obj_.type == 'MESH')

        act_obj_uv_layers = active_obj.data.uv_layers

        uv_presets = settings.uv_layers_presets
        UNIV_OT_UV_Layers_Manager.sanitize_size(uv_presets)

        if act_obj_uv_layers:
            act_obj_uv_layers_size = len(act_obj_uv_layers)
            if act_obj_uv_layers_size > 8:
                for preset, uv in zip(uv_presets, act_obj_uv_layers):
                    preset.name = uv.name
                    preset.flag = 2
                settings.uv_layers_size = 8
                utils.update_univ_panels()
                return
            act_obj_uv_idx = 0
            act_obj_uv_render_idx = 0
            for idx, uv in enumerate(act_obj_uv_layers):
                if uv.active:
                    act_obj_uv_idx = idx
                if uv.active_render:
                    act_obj_uv_render_idx = idx

            act_obj_uv_names = tuple(uv.name for uv in act_obj_uv_layers)
            act_obj_uv_names_tags = [True for _ in act_obj_uv_names]
            for obj in selected_objects:
                uv_layers = obj.data.uv_layers
                uv_layers_size = len(uv_layers)
                # Frequent case
                if uv_layers_size == act_obj_uv_layers_size:
                    for idx, uv in enumerate(uv_layers):

                        if act_obj_uv_names_tags[idx]:
                            if act_obj_uv_names[idx] != uv.name:
                                act_obj_uv_names_tags[idx] = False

                        if uv.active:
                            if act_obj_uv_idx != idx:
                                act_obj_uv_names_tags[idx] = False

                        if uv.active_render:
                            if act_obj_uv_render_idx != idx:
                                act_obj_uv_names_tags[idx] = False

                elif uv_layers_size > act_obj_uv_layers_size:
                    settings.uv_layers_size = uv_layers_size
                    for idx, uv in enumerate(uv_layers):
                        if idx == 8:
                            break
                        preset = uv_presets[idx]
                        if idx < act_obj_uv_layers_size:
                            preset.name = act_obj_uv_names[idx]
                            preset.flag = not act_obj_uv_names_tags[idx]
                        else:
                            preset.name = uv.name
                            preset.flag = 2

                    if settings.uv_layers_active_idx >= uv_layers_size - 1:
                        settings.uv_layers_active_idx = uv_layers_size - 1  # clamp
                        settings.uv_layers_active_render_idx = act_obj_uv_render_idx
                    utils.update_univ_panels()
                    return

                else:  # uv_layers_size < act_obj_uv_layers_size:
                    settings.uv_layers_size = act_obj_uv_layers_size
                    if not uv_layers_size:
                        for idx in range(act_obj_uv_layers_size):
                            preset = uv_presets[idx]
                            preset.name = act_obj_uv_names[idx]
                            preset.flag = 2

                        settings.uv_layers_active_idx = act_obj_uv_idx
                        settings.uv_layers_active_render_idx = -1
                        utils.update_univ_panels()
                        return

                    for idx in range(act_obj_uv_layers_size):
                        preset = uv_presets[idx]
                        if idx < uv_layers_size:
                            preset.name = act_obj_uv_names[idx]
                            preset.flag = not act_obj_uv_names_tags[idx]
                        else:
                            preset.name = act_obj_uv_names[idx]
                            preset.flag = 2

                    settings.uv_layers_active_render_idx = -1
                    if settings.uv_layers_active_idx > act_obj_uv_layers_size - 1:
                        settings.uv_layers_active_idx = act_obj_uv_layers_size - 1
                    utils.update_univ_panels()
                    return

            for idx in range(act_obj_uv_layers_size):
                preset = uv_presets[idx]
                preset.name = act_obj_uv_names[idx]
                preset.flag = not act_obj_uv_names_tags[idx]

            settings.uv_layers_size = act_obj_uv_layers_size
            settings.uv_layers_active_idx = act_obj_uv_idx
            settings.uv_layers_active_render_idx = act_obj_uv_render_idx
        elif selected_objects:
            obj_with_max_uv = max(selected_objects, key=lambda ob: len(ob.data.uv_layers))
            uv_layers = obj_with_max_uv.data.uv_layers
            uv_layers_size = len(uv_layers)

            settings.uv_layers_size = uv_layers_size

            for preset, uv in zip(uv_presets, uv_layers):
                preset.name = uv.name
                preset.flag = 2

            settings.uv_layers_active_idx = 0
            settings.uv_layers_active_render_idx = -1
        else:
            if settings.uv_layers_size:
                settings.uv_layers_size = 0
                utils.update_univ_panels()
            return
        utils.update_univ_panels()

    @staticmethod
    def sanitize_size(presets):
        size = len(presets)
        if size == 8:
            return

        if size < 8:
            for _ in range(8-size):
                presets.add()
        else:
            for i in range(len(presets), 8, -1):
                presets.remove(i-1)

    @staticmethod
    @bpy.app.handlers.persistent
    def univ_uv_layers_update(_, deps):
        for update_obj in deps.updates:
            if update_obj.is_updated_transform:
                return
            else:
                from .. import ui
                ui.REDRAW_UV_LAYERS = True
                return

    @staticmethod
    def uv_layers_watcher_append_handler():
        try:
            if univ_settings().uv_layers_show:
                bpy.app.handlers.depsgraph_update_post.append(UNIV_OT_UV_Layers_Manager.univ_uv_layers_update)
        except Exception as e:
            print('UniV: Failed to add a handler for UV Layer system.', e)


class UNIV_OT_MoveUpDownBase(Operator):
    bl_options = {'REGISTER', 'UNDO'}
    # noinspection PyTypeHints
    with_names: BoolProperty(default=False, options={'HIDDEN'})

    def invoke(self, context, event):
        if event.value == 'PRESS':
            return self.execute(context)
        self.with_names = not event.alt
        return self.execute(context)

    @classmethod
    def move_uv_bm(cls, obj, idx, up, with_names=False):
        idx_inc_dec = 1
        layers = obj.data.uv_layers
        if up:
            if idx == 0 or len(layers) == 0 or len(layers) < idx + 1:
                return False
        else:
            idx_inc_dec = -1
            if len(layers) <= idx + 1:
                return False

        other_idx = idx - idx_inc_dec
        if bpy.context.mode == 'EDIT_MESH':
            cls._swap_uv_bm(obj, idx, other_idx, with_names)
        else:
            cls._swap_uv_mesh(obj, idx, other_idx, with_names)
        return True

    @staticmethod
    def _swap_uv_bm(obj, idx, other_idx, with_names, change_active_idx=True):
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        uv = bm.loops.layers.uv.verify()
        other_uv = bm.loops.layers.uv[other_idx]
        layers = mesh.uv_layers

        coords = [crn[uv].uv.copy() for f in bm.faces for crn in f.loops]
        it = (crn[other_uv].uv for f in bm.faces for crn in f.loops)

        for uv_a_copy, uv_b in zip(coords, it):
            uv_b_copy = uv_b.copy()
            uv_b[:] = uv_a_copy
            uv_a_copy[:] = uv_b_copy

        layers.active_index = idx

        it = (crn for f in bm.faces for crn in f.loops)
        for uv_b_copy, crn_a in zip(coords, it):
            crn_a[uv].uv = uv_b_copy

        if change_active_idx:  # small optimization
            layers.active_index = other_idx

        if with_names:
            name_a = layers[idx].name
            name_b = layers[other_idx].name
            layers[idx].name = 'temp'
            layers[other_idx].name = name_a
            layers[idx].name = name_b

    @staticmethod
    def _swap_uv_mesh(obj, idx, other_idx, with_names, change_active_idx=True):
        size = len(obj.data.loops) * 2
        uvs_a = np.empty(size, dtype='float32')
        uvs_b = np.empty(size, dtype='float32')

        layers = obj.data.uv_layers
        uv_layer_a = layers[idx]
        uv_layer_b = layers[other_idx]
        uv_layer_a.data.foreach_get("uv", uvs_a)
        uv_layer_b.data.foreach_get("uv", uvs_b)

        uv_layer_a.data.foreach_set("uv", uvs_b)
        uv_layer_b.data.foreach_set("uv", uvs_a)

        if change_active_idx:  # small optimization
            if layers.active_index != other_idx:
                layers.active_index = other_idx

        if with_names:
            name_a = layers[idx].name
            name_b = layers[other_idx].name
            layers[idx].name = 'temp'
            layers[other_idx].name = name_a
            layers[idx].name = name_b


class UNIV_OT_MoveUp(UNIV_OT_MoveUpDownBase):
    bl_idname = 'mesh.univ_move_up'
    bl_label = 'Up'
    bl_description = ("Move Up UV Layer \n"
                      "Alt+Click - Moves only the UV layer, keeping name in place.")

    def execute(self, context):
        settings = univ_settings()
        if settings.uv_layers_active_idx == 0:
            self.report({'WARNING'}, 'Cannot move up')
            return {'CANCELLED'}

        selected_objects = utils.calc_any_unique_obj()
        if not selected_objects:
            self.report({'WARNING'}, "Not found uvs or selected mesh objects.")
            return {'CANCELLED'}

        is_edit_mode = bpy.context.mode == 'EDIT_MESH'
        for obj in selected_objects:
            do_update = self.move_uv_bm(obj, settings.uv_layers_active_idx, up=True, with_names=self.with_names)
            if do_update:
                if is_edit_mode:
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                else:
                    obj.data.update()

        if not is_edit_mode:
            utils.update_area_by_type('VIEW_3D')
        return {'FINISHED'}


class UNIV_OT_MoveDown(UNIV_OT_MoveUpDownBase):
    bl_idname = 'mesh.univ_move_down'
    bl_label = 'Down'
    bl_description = ("Move Down UV Layer \n"
                      "Alt+Click - Moves only the UV layer, keeping name in place.")

    def execute(self, context):
        settings = univ_settings()
        if settings.uv_layers_size == settings.uv_layers_active_idx + 1:
            self.report({'WARNING'}, 'Cannot move down')
            return {'CANCELLED'}

        selected_objects = utils.calc_any_unique_obj()
        if not selected_objects:
            self.report({'WARNING'}, "Not found uvs or selected mesh objects.")
            return {'CANCELLED'}

        is_edit_mode = bpy.context.mode == 'EDIT_MESH'
        for obj in selected_objects:
            do_update = self.move_uv_bm(obj, settings.uv_layers_active_idx, up=False, with_names=self.with_names)
            if do_update:
                if is_edit_mode:
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                else:
                    obj.data.update()

        if not is_edit_mode:
            utils.update_area_by_type('VIEW_3D')

        return {'FINISHED'}


class UNIV_OT_Add(Operator):
    bl_idname = 'mesh.univ_add'
    bl_label = 'Add'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = ("Add UV Layer \n"
                      "Alt+Click - Add missed UV layers.")
    # noinspection PyTypeHints
    add_missed: BoolProperty(name='Add with Missed', default=False)


    def invoke(self, context, event):
        if event.value == 'PRESS':
            return self.execute(context)
        self.add_missed = event.alt
        return self.execute(context)

    def execute(self, context):
        settings = univ_settings()
        objects = utils.calc_any_unique_obj()
        if not objects:
            self.report({'WARNING'}, 'Objects not found')
            return {'CANCELLED'}

        target_min_size = min(len(obj.data.uv_layers) for obj in objects) + 1
        if self.add_missed:
            target_max_size = max(len(obj.data.uv_layers) for obj in objects) + 1
            if target_min_size != target_max_size:
                target_min_size = target_max_size - 1

        if target_min_size > 8:
            self.report({'WARNING'}, 'The limit of 8 channels has been reached.')
            return {'CANCELLED'}

        is_edit_mode = bpy.context.mode == 'EDIT_MESH'
        for obj in objects:
            if is_edit_mode:
                if self.add_missed_uvs_bm(obj, target_min_size, settings.uv_layers_active_idx):
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            else:
                if UNIV_OT_Join.add_missed_uvs(obj, target_min_size, settings.uv_layers_active_idx):
                    obj.data.update()

        if not is_edit_mode:
            utils.update_area_by_type('VIEW_3D')
        return {'FINISHED'}

    @staticmethod
    def add_missed_uvs_bm(obj, target_size, active_index):
        assert target_size <= 8
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        uv_size = len(bm.loops.layers.uv)
        if target_size == 0 or uv_size == target_size or uv_size >= 8:
            return 0

        if uv_size == 0:
            while (len(bm.loops.layers.uv)) < target_size:
                bm.loops.layers.uv.new('UVMap')
            return target_size

        counter = 0
        uv = bm.loops.layers.uv.verify()
        if uv_size >= active_index + 1:
            if mesh.uv_layers.active_index != active_index:
                mesh.uv_layers.active_index = active_index

        coords = [crn[uv].uv.copy() for f in bm.faces for crn in f.loops]

        while (len(bm.loops.layers.uv)) < target_size:
            uv = bm.loops.layers.uv.new('UVMap')
            obj.data.uv_layers.active_index = len(mesh.uv_layers) - 1
            corners = (crn for f in bm.faces for crn in f.loops)
            for crn, uv_co in zip(corners, coords):
                crn[uv].uv = uv_co
            counter += 1
        bm = bm  # noqa
        return counter


class UNIV_OT_Remove(Operator):
    bl_idname = 'mesh.univ_remove'
    bl_label = 'Remove'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = ("Remove UV Layer \n"
                      "Alt+Click - Remove all UV layers.")
    # noinspection PyTypeHints
    remove_all: BoolProperty(name='Remove All', default=False)


    def invoke(self, context, event):
        if event.value == 'PRESS':
            return self.execute(context)
        self.remove_all = event.alt
        return self.execute(context)

    def execute(self, context):
        objects = utils.calc_any_unique_obj()
        if not objects:
            self.report({'WARNING'}, 'Objects not found')
            return {'CANCELLED'}

        max_size = max(len(obj.data.uv_layers) for obj in objects)

        if max_size == 0:
            self.report({'WARNING'}, 'All uv maps removed')
            return {'CANCELLED'}

        is_edit_mode = bpy.context.mode == 'EDIT_MESH'
        target_idx = univ_settings().uv_layers_active_idx
        for obj in objects:
            mesh = obj.data
            uv_layers = mesh.uv_layers
            if not uv_layers:
                continue

            if self.remove_all:
                if is_edit_mode:
                    bm = bmesh.from_edit_mesh(mesh)
                    for uv_layer in reversed(bm.loops.layers.uv):
                        bm.loops.layers.uv.remove(uv_layer)
                    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
                else:
                    for uv_layer in reversed(uv_layers):
                        uv_layers.remove(uv_layer)
                    obj.data.update()
            else:
                if len(uv_layers) >= target_idx + 1:
                    if is_edit_mode:
                        bm = bmesh.from_edit_mesh(mesh)
                        bm.loops.layers.uv.remove(bm.loops.layers.uv[target_idx])
                        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                    else:
                        uv_layers.remove(uv_layers[target_idx])
                        obj.data.update()

        if not is_edit_mode:
            utils.update_area_by_type('VIEW_3D')
        return {'FINISHED'}


class UNIV_OT_CopyToLayer(Operator):
    bl_idname = 'uv.univ_copy_to_layer'
    bl_label = 'Copy'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        copy_from = int(univ_settings().copy_to_layers_from)
        copy_to = int(univ_settings().copy_to_layers_to)

        if copy_from != 0:
            if copy_from == copy_to:
                self.report({'WARNING'}, 'The From and To indexes are identical')
                return {'CANCELLED'}

        umeshes = UMeshes(report=self.report)
        source_and_target_same_count = 0
        missed_source_meshes_count = 0
        missed_target_meshes_count = 0
        if umeshes.is_edit_mode:
            if context.area.type != 'IMAGE_EDITOR':
                umeshes.set_sync()
                umeshes.sync_invalidate()

            selected, visible = umeshes.filtered_by_selected_and_visible_uv_edges()
            umeshes = selected if selected else visible
            if not umeshes:
                return umeshes.update()

            for umesh in reversed(umeshes):
                if len(umesh.obj.data.uv_layers) == 1:
                    umeshes.umeshes.remove(umesh)
            if not umeshes:
                return umeshes.update(info='Not found meshes with 2 and more uvs for copy coordinates')

            for umesh in reversed(umeshes):
                if copy_from == 0:
                    donor_uv = umesh.uv
                else:
                    if len(umesh.obj.data.uv_layers) < copy_from:
                        umeshes.umeshes.remove(umesh)
                        missed_source_meshes_count += 1
                        continue
                    donor_uv = umesh.bm.loops.layers.uv[copy_from-1]

                faces = utils.calc_selected_uv_faces(umesh) if selected else utils.calc_visible_uv_faces(umesh)
                if copy_to == 0:
                    for idx in range(len(umesh.obj.data.uv_layers)):
                        recipient_uv = umesh.bm.loops.layers.uv[idx]
                        if donor_uv.name == recipient_uv.name:
                            continue

                        for f in faces:
                            for crn in f.loops:
                                crn[recipient_uv].uv = crn[donor_uv].uv
                else:
                    if len(umesh.obj.data.uv_layers) < copy_to:
                        umeshes.umeshes.remove(umesh)
                        missed_target_meshes_count += 1
                        continue

                    recipient_uv = umesh.bm.loops.layers.uv[copy_to-1]
                    if recipient_uv.name == donor_uv.name:
                        umeshes.umeshes.remove(umesh)
                        source_and_target_same_count += 1
                        continue

                    for f in faces:
                        for crn in f.loops:
                            crn[recipient_uv].uv = crn[donor_uv].uv

        else:
            if not umeshes:
                return umeshes.update()

            for umesh in reversed(umeshes):
                if len(umesh.obj.data.uv_layers) == 1:
                    umeshes.umeshes.remove(umesh)
            if not umeshes:
                return umeshes.update(info='Not found meshes with 2 and more uvs for copy coordinates')

            for umesh in reversed(umeshes):
                if copy_from == 0:
                    donor_uv = umesh.obj.data.uv_layers.active
                else:
                    if len(umesh.obj.data.uv_layers) < copy_from:
                        umeshes.umeshes.remove(umesh)
                        missed_source_meshes_count += 1
                        continue
                    donor_uv = umesh.obj.data.uv_layers[copy_from - 1]

                size = len(umesh.obj.data.loops) * 2
                donor_uv_coords = np.empty(size, dtype='float32')
                donor_uv.data.foreach_get("uv", donor_uv_coords)

                if copy_to == 0:
                    for idx in range(len(umesh.obj.data.uv_layers)):
                        recipient_uv = umesh.obj.data.uv_layers[idx]
                        if donor_uv.name == recipient_uv.name:
                            continue
                        recipient_uv.data.foreach_set("uv", donor_uv_coords)
                else:
                    if len(umesh.obj.data.uv_layers) < copy_to:
                        umeshes.umeshes.remove(umesh)
                        missed_target_meshes_count += 1
                        continue

                    recipient_uv = umesh.obj.data.uv_layers[copy_to - 1]
                    if recipient_uv.name == donor_uv.name:
                        umeshes.umeshes.remove(umesh)
                        source_and_target_same_count += 1
                        continue
                    recipient_uv.data.foreach_set("uv", donor_uv_coords)

        info = ''
        if source_and_target_same_count:
            info += f'{source_and_target_same_count} meshes has same source and target UV channel. '
        if missed_source_meshes_count:
            info += f'{missed_source_meshes_count} meshes do not have the required source UV channel to provide coordinates for transfer. '
        if missed_target_meshes_count:
            info += f'{missed_target_meshes_count} meshes do not have the required target UV channel to receive source coordinates.'
        if info:
            self.report({'WARNING'}, info)

        if umeshes.is_edit_mode:
            umeshes.silent_update()
        else:
            for umesh in umeshes:
                umesh.obj.update_tag()
            umeshes.free()
            utils.update_area_by_type('VIEW_3D')

        return {'FINISHED'}


class UNIV_OT_SetActiveRender(Operator):
    bl_idname = 'mesh.univ_active_render_set'
    bl_label = 'Remove'
    bl_options = {'REGISTER', 'UNDO'}
    # noinspection PyTypeHints
    idx: IntProperty(name='Set Active', default=0, min=0, max=8, options={'HIDDEN'})

    def execute(self, context):
        objects = utils.calc_any_unique_obj()
        if not objects:
            self.report({'WARNING'}, 'Mesh objects not found.')
            return {'CANCELLED'}

        for obj in objects:
            mesh = obj.data
            uv_layers = mesh.uv_layers
            if len(uv_layers) >= self.idx + 1:
                if not uv_layers[self.idx].active_render:
                    uv_layers[self.idx].active_render = True
        return {'FINISHED'}


class UNIV_OT_FixUVs(Operator):
    bl_idname = "mesh.univ_fix_uvs"
    bl_label = "Fix UVs"
    bl_description = "Fix channels"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        objects = utils.calc_any_unique_obj()
        if not objects:
            self.report({'WARNING'}, 'Objects not found')
            return {'CANCELLED'}

        removed_extra_channels_counter = sum(UNIV_OT_Join.sanitize_uv(self.report, obj.data) for obj in objects)

        uv_names, conflicts_counter = UNIV_OT_Join.sanitize_attr_names_and_get_names(objects)

        max_uv_size = max(len(obj.data.uv_layers) for obj in objects)
        if not max_uv_size:
            if preferences.debug():
                self.report({'WARNING'}, 'UVs not found')
            return {'CANCELLED'}

        added_uvs_counter = 0
        for obj in objects:
            if bpy.context.mode == 'EDIT_MESH':
                if UNIV_OT_Add.add_missed_uvs_bm(obj, max_uv_size, 8):
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            else:
                res = UNIV_OT_Join.add_missed_uvs(obj, max_uv_size)
                if res:
                    added_uvs_counter += res

            UNIV_OT_Join.rename_uvs(self.report, uv_names, obj.data)

        active_uv_idx = 0
        active_render_uv_idx = 0
        for idx, uv in enumerate(bpy.context.active_object.data.uv_layers):
            if uv.active:
                active_uv_idx = idx
            if uv.active_render:
                active_render_uv_idx = idx

        for obj in objects:
            mesh = obj.data
            uv_layers = mesh.uv_layers
            uv_layers[active_uv_idx].active = True
            uv_layers[active_render_uv_idx].active_render = True
            mesh.update()

        if bpy.context.mode == 'EDIT_MESH':
            if bpy.context.area.type == 'VIEW_3D':
                bpy.ops.mesh.univ_seam_border(selected=False, mtl=False, by_sharps=False)  # noqa
            else:
                bpy.ops.uv.univ_seam_border(selected=False, mtl=False, by_sharps=False)  # noqa

        info = ''
        if conflicts_counter:
            info += f"Resolved {conflicts_counter!r} uv names conflicts. "
        if removed_extra_channels_counter:
            info += f"Removed {removed_extra_channels_counter!r} extra channels in total."
        if added_uvs_counter:
            info += f"Added {added_uvs_counter!r} channels in total."

        if info:
            self.report({'WARNING'}, info)

        return {'FINISHED'}


class UNIV_OT_SmartScaleApply(Operator):
    bl_idname = "mesh.univ_smart_scale_apply"
    bl_label = "Smart Scale Apply"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply scale and invert normals. Fixes modifier and worked with instances"


    def execute(self, context):
        UNIFORM_SCALE = Vector((1.0, 1.0, 1.0))
        FLIP_PATTERN = [[1, 1, -1], [1, -1, 1], [-1, 1, 1], [-1, -1, -1]]

        count = 0
        selected_object_with_instances = utils.get_selected_object_with_instances()
        if not selected_object_with_instances:
            self.report({'WARNING'}, 'Not found selected meshes')
            return {'CANCELLED'}

        prev_mode = bpy.context.mode
        if prev_mode == 'EDIT_MESH':
            if bpy.ops.object.mode_set.poll():
                # TODO: No switch to object mode, when all objects is uniform
                bpy.ops.object.mode_set(mode='OBJECT')

        for ob, instances in selected_object_with_instances:
            if ob.scale == UNIFORM_SCALE:
                continue

            if 0.0 in ob.scale:
                # TODO: Apply scale, if has not instances (and modifiers?)
                self.report({'WARNING'}, f"Object {ob.name} has zero scale component {ob.scale!r} and was skipped.")
                continue

            count += 1
            me = ob.data
            scale = ob.scale.copy()
            pattern = [1 if (i > 0) else -1 for i in scale]
            flip = pattern in FLIP_PATTERN

            distance_scaler = min(ob.scale, key=lambda x: abs(1 - x))
            for mod in ob.modifiers:
                self.modifier_compensation(mod, scale, distance_scaler, scale)


            # TODO: Check with auto smooth
            mirror_split_normals = []
            if me.has_custom_normals and getattr(me, 'use_auto_smooth', False):
                if hasattr(me, 'calc_normals_split'):
                    me.calc_normals_split()

                    if flip:
                        mirror_split_normals = [me.loops[i].normal * Vector(pattern)
                                                for iter_poly in me.polygons
                                                for i in [iter_poly.loop_indices[0]] +
                                                [*reversed(iter_poly.loop_indices[1:])]]
                    else:
                        mirror_split_normals = [me.loops[i].normal * Vector(pattern)
                                                for iter_poly in me.polygons
                                                for i in iter_poly.loop_indices]

            scale_mtx = Matrix.Diagonal(scale).to_4x4()
            me.transform(scale_mtx)

            if flip:
                me.flip_normals()

            if mirror_split_normals:
                if me.has_custom_normals and getattr(me, 'use_auto_smooth', False):
                    me.normals_split_custom_set(mirror_split_normals)

            ob.scale = UNIFORM_SCALE

            for inst in instances:
                try:
                    compensation = [inst.scale[i] / scale[i] for i in range(3)]

                    # TODO: Use distance_scaler by modifier
                    distance_scaler = min([abs(x / i) for x, i in zip(inst.scale, compensation)])

                    for mod in inst.modifiers:
                        self.modifier_compensation(mod, scale, distance_scaler, inst.scale.copy())
                    inst.scale = Vector(compensation)
                except ZeroDivisionError:
                    self.report({'WARNING'}, f"Object {inst.name!r} has zero scale: {inst.scale!r}, and was reset.")
                    inst.scale = UNIFORM_SCALE

        if count:
            self.report({'INFO'}, f"Fixed scales for {count!r} selected objects")
        else:
            self.report({'INFO'}, f"All selected objects has uniform scale")

        from .inspect import INSPECT_INFO
        info_list = INSPECT_INFO.get('Other')
        if info_list:
            for i, (check_type, _) in enumerate(info_list):
                if check_type == 'Unapplied Scales':
                    del info_list[i]
                    break

        if prev_mode == 'EDIT_MESH':
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode='EDIT')


        return {'FINISHED'}

    @staticmethod
    def modifier_compensation(mod, tar_scale, var, cur_scale):
        match mod.type:
            case 'ARRAY':
                if mod.use_constant_offset:
                    mod.constant_offset_displace *= tar_scale
                mod.merge_threshold *= var
                if mod.use_relative_offset:
                    rel_sign = Vector([1 if i > 0 else -1 for i in tar_scale])
                    mod.relative_offset_displace *= rel_sign
            case 'NODES':
                if 'Array' not in mod.name:
                    return

                gn_mod = utils.GN(mod, print_missed_socket=True)
                del mod
                shape_type_sk = "Socket_2"
                offset_method_type_sk = "Socket_14"

                array_offset_sk = 'Socket_21'
                transform_reference_sk = 'Socket_25'
                array_translation_sk = 'Socket_8'
                array_rotation_sk = 'Socket_9'

                curve_count_method_distance_sk = 'Socket_33'
                curve_distance_sk = 'Socket_34'

                merge_sk = 'Socket_31'
                distance_sk = 'Socket_32'

                circle_central_axis_sk = 'Socket_11'
                circle_radius_sk = 'Socket_6'

                if shape_type_sk not in gn_mod:
                    return
                if offset_method_type_sk not in gn_mod:
                    return

                match gn_mod[shape_type_sk]:
                    case "Line" | 0:
                        match gn_mod[offset_method_type_sk]:
                            case "Relative" | 2:
                                rel_sign = Vector([1 if i > 0 else -1 for i in tar_scale])
                                gn_mod[array_offset_sk][:] = Vector(gn_mod[array_offset_sk]) * rel_sign  # Rescale offset.
                            case "Offset" | 0:
                                gn_mod[array_translation_sk][:] = Vector(gn_mod[array_translation_sk]) * tar_scale
                            case "Endpoint" | 1:
                                gn_mod[array_translation_sk][:] = Vector(gn_mod[array_translation_sk]) * tar_scale
                            case offset_method:
                                print(f"UniV: Smart Scale Apply: Unknow shape type {offset_method!r}")
                                return

                        # TODO: Add rotation fix for other types
                        import math
                        import mathutils

                        rot = mathutils.Euler(gn_mod[array_rotation_sk])
                        scale_mat = Matrix.Diagonal(cur_scale).to_3x3()

                        # Adjust the rotation using the scale.
                        fixed_mat = scale_mat @ rot.to_matrix() @ scale_mat.inverted_safe()

                        rot = fixed_mat.to_euler()
                        # Round to avoid float point error and remove sign
                        for i, v in enumerate(rot):
                            if math.isclose(v, 0, abs_tol=1e-7):
                                rot[i] = 0

                        gn_mod[array_rotation_sk][:] = rot

                    case "Circle" | 1:
                        # TODO: Implement radius by axis
                        match gn_mod[circle_central_axis_sk]:
                            case "X" | 0:  # X
                                pass
                            case "Y" | 1:  # Y
                                pass
                            case "Z" | 2:  # Z
                                pass

                        gn_mod[circle_radius_sk] *= abs(var)
                    case "Curve" | 2:
                        if gn_mod[curve_count_method_distance_sk] in ("Distance", 1):
                            gn_mod[curve_distance_sk] *= abs(var)
                    case "Transform" | 3:
                        if gn_mod[transform_reference_sk] in ("Inputs", 0):
                            gn_mod[array_translation_sk][:] = Vector(gn_mod[array_translation_sk]) * tar_scale
                    case shape_type:
                        print(f"UniV: Smart Scale Apply: Unknow shape type {shape_type!r}")

                # Correct distance.
                gn_mod.print_error = False
                if merge_sk in gn_mod:
                    if gn_mod[merge_sk]:
                        if distance_sk in gn_mod:
                            gn_mod[distance_sk] *= abs(var)
                        else:
                            print(f"UniV: Smart Scale Apply: Can't found distance merge socket")
                else:
                    print(f"UniV: Smart Scale Apply: Can't found merge socket")

            case 'BEVEL':
                mod.width *= abs(var)
            case 'SOLIDIFY':
                mod.thickness *= var
            case 'BOOLEAN':
                mod.double_threshold *= abs(var)
            case 'MIRROR':
                mod.merge_threshold *= abs(var)

                for i in range(3):
                    if mod.use_axis[i] and mod.use_bisect_axis[i] and tar_scale[i] < 0:
                        mod.use_bisect_flip_axis[i] ^= 1
            case 'SCREW':
                mod.screw_offset *= getattr(tar_scale, mod.axis.lower())
                mod.merge_threshold *= abs(var)
            case 'WIREFRAME':
                mod.thickness *= abs(var)
            case 'CAST':
                mod.radius *= abs(var)
            case 'HOOK':
                mod.falloff_radius *= abs(var)
            case 'SHRINKWRAP':
                mod.offset *= abs(var)
            case 'WARP':
                mod.falloff_radius *= abs(var)
            case 'WELD':
                mod.merge_threshold *= abs(var)
            case 'DISPLACE':
                if mod.direction in ('X', 'Y'):
                    mod.strength *= getattr(tar_scale, mod.direction.lower())
                else:
                    mod.strength *= tar_scale.z


def draw_smart_scale_menu(self, _context):
    self.layout.operator("mesh.univ_smart_scale_apply")

# noinspection PyTypeHints
class UNIV_OT_AlignBorderVerts(Operator):
    bl_idname = "uv.univ_align_border_verts"
    bl_label = "Align Border Verts"
    bl_description = "Align selected shared border vertices coords by orthogonal edge axis"
    bl_options = {'REGISTER', 'UNDO'}

    flip_order: BoolProperty(name='Flip Order', default=False, description="From Left->Right, Bottom->Upper to Right->Left, Upper->Bottom.")
    is_orthogonal_axis: BoolProperty(name='Orthogonal Axis', default=True)
    use_aspect: BoolProperty(name='Correct Aspect', default=True)

    def execute(self, context):
        if bpy.context.mode != 'EDIT_MESH':
            self.report({'WARNING'}, "Edit mode is required.")
            return {'CANCELLED'}

        umeshes = UMeshes()
        if not umeshes:
            return umeshes.update()

        umeshes.filter_by_selected_uv_edges()
        if not umeshes:
            self.report({'WARNING'}, 'Selected uv edges not found')
            return {"CANCELLED"}

        def is_vertical(vec):
            return abs(vec.y) > abs(vec.x)

        aspect = 1.0
        if self.use_aspect:
            aspect = utils.get_aspect_ratio()
        aspect_vec = Vector((1 / aspect, 1))

        utils.get_aspect_ratio()
        for umesh in umeshes:
            is_boundary_with_pair = utils.is_boundary_func(umesh, with_seam=False)
            boundary_with_pair_edges = []
            for crn in utils.calc_selected_uv_edge_iter(umesh):
                 if crn.edge.is_contiguous and is_boundary_with_pair(crn):
                     boundary_with_pair_edges.append(crn)

            umesh.update_tag = bool(boundary_with_pair_edges)
            if not umesh.update_tag:
                continue

            v = []
            h = []
            for seg in utypes.Segments.from_corners(boundary_with_pair_edges, umesh):
                center = (seg.start_co - seg.end_co)

                if is_vertical(center * aspect_vec):
                    seg.value = center.x
                    v.append(seg)
                else:
                    seg.value = center.y
                    h.append(seg)


            v.sort(key = lambda s: s.value, reverse=True)
            h.sort(key = lambda s: s.value, reverse=True)

            if not self.is_orthogonal_axis:
                v, h = h, v

            v = [adv_crn.crn.link_loop_prev if adv_crn.invert else adv_crn.crn for seg in v for adv_crn in seg]
            h = [adv_crn.crn.link_loop_prev if adv_crn.invert else adv_crn.crn for seg in h for adv_crn in seg]
            if self.flip_order:
                v = [crn.link_loop_radial_prev for crn in v]
                h = [crn.link_loop_radial_prev for crn in h]


            uv = umesh.uv
            sync = umesh.sync
            for crn in h:
                linked_corners_a = [l_crn for l_crn in utils.linked_crn_to_vert_pair_with_seam(crn, uv, sync)]
                linked_corners_a.append(crn)
                linked_corners_b = [l_crn for l_crn in utils.linked_crn_to_vert_pair_with_seam(crn.link_loop_next, uv, sync)]
                linked_corners_b.append(crn.link_loop_next)

                shared_crn = crn.link_loop_radial_prev
                x = shared_crn[uv].uv.x
                for l_crn in linked_corners_b:
                    l_crn[uv].uv.x = x

                shared_crn_next = shared_crn.link_loop_next
                x = shared_crn_next[uv].uv.x
                for l_crn in linked_corners_a:
                    l_crn[uv].uv.x = x

            for crn in v:
                linked_corners_a = [l_crn for l_crn in utils.linked_crn_to_vert_pair_with_seam(crn, uv, sync)]
                linked_corners_a.append(crn)
                linked_corners_b = [l_crn for l_crn in utils.linked_crn_to_vert_pair_with_seam(crn.link_loop_next, uv, sync)]
                linked_corners_b.append(crn.link_loop_next)

                shared_crn = crn.link_loop_radial_prev
                y = shared_crn[uv].uv.y
                for l_crn in linked_corners_b:
                    l_crn[uv].uv.y = y

                shared_crn_next = shared_crn.link_loop_next
                y = shared_crn_next[uv].uv.y
                for l_crn in linked_corners_a:
                    l_crn[uv].uv.y = y


        umeshes.update(info='Not found border contiguous selected uv edges.')
        return {'FINISHED'}
